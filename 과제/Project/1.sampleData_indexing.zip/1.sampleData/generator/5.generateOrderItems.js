import { SelectID } from "./3.generateOrders.js";
import { UUIDGenerator } from "../utils.js";

export class OrderItemGenerator {
  constructor() {
    this.orderIdGen = new SelectID(
      "results/order.csv",
      "results/3.generateOrders_index.csv"
    );
    this.itemIdGen = new SelectID(
      "results/item.csv",
      "results/4.generateProducts_index.csv"
    );
  }

  async generateData(count) {
    let data = [];
    for (let i = 0; i < count; i++) {
      this.uuid = UUIDGenerator.generateUUID();
      let orderId = await this.orderIdGen.selectID();
      let itemId = await this.itemIdGen.selectID();

      data.push([this.uuid, orderId, itemId]);
    }
    return data;
  }
}
